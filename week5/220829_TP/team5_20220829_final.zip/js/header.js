function linkTo(address) {
    location.href=address;
}